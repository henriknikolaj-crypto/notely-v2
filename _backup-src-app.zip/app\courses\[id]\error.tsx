﻿"use client";
export default function Error() {
  return <div className="p-6 text-red-600">Noget gik galt ved indlæsning.</div>;
}
﻿"use client";
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";

type EvalResult = {
  ok?: boolean;
  score?: number;
  feedback?: string;
  references?: { title?: string; url?: string }[];
  error?: string;
};

export default function ClientExamUX() {
  const [question, setQuestion] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [answer, setAnswer] = useState("");
  const [includeBackground, setIncludeBackground] = useState(true);
  const [loadingGen, setLoadingGen] = useState(false);
  const [loadingEval, setLoadingEval] = useState(false);
  const [result, setResult] = useState<EvalResult | null>(null);

  async function generateQuestion() {
    try {
      setLoadingGen(true);
      setResult(null);
      const res = await fetch("/api/generate-question", { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        alert(data?.error ?? "Generering fejlede");
        return;
      }
      setQuestion(data.question ?? null);
      setSessionId(data.sessionId ?? null);
      setAnswer("");
    } catch (e: any) {
      console.error(e);
      alert(e?.message ?? "Uventet fejl ved generering");
    } finally {
      setLoadingGen(false);
    }
  }

  async function evaluate() {
    if (!question) {
      alert("Der er ikke noget spørgsmål endnu.");
      return;
    }
    try {
      setLoadingEval(true);
      const body = {
        question,
        answer,
        sessionId,
        includeReferences: includeBackground,
        withReferences: includeBackground,
      };
      const res = await fetch("/api/evaluate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await res.json()) as EvalResult & { error?: string };
      if (!res.ok) {
        console.error("evaluate error", data);
        alert(data?.error ?? "Evaluering fejlede");
        return;
      }
      setResult({
        ok: true,
        score: data.score ?? 0,
        feedback: data.feedback ?? "",
        references: data.references ?? [],
      });
    } catch (e: any) {
      console.error(e);
      alert(e?.message ?? "Uventet fejl ved evaluering");
    } finally {
      setLoadingEval(false);
    }
  }

  function resetAnswer() {
    setAnswer("");
    setResult(null);
  }

  return (
    <section style={{ display: "grid", gap: 16 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <h1 style={{ fontSize: 28, fontWeight: 700 }}>Eksamensøvelse</h1>
        <button
          onClick={generateQuestion}
          disabled={loadingGen}
          style={{ border: "1px solid #cbd5e1", padding: "6px 10px", borderRadius: 6, opacity: loadingGen ? .6 : 1 }}
        >
          {loadingGen ? "Genererer..." : "Generér nyt spørgsmål"}
        </button>
      </div>

      <div>
        {question ? (
          <p><strong>Spørgsmål:</strong> {question}</p>
        ) : (
          <p>Ingen aktiv opgave. Klik Generér nyt spørgsmål.</p>
        )}
      </div>

      {/* --- DIT SVAR (kun én hvid boks: textarea) --- */}
      <div style={{ padding: 0, background: "transparent" }}>
        <label htmlFor="answerBox" style={{ display: "block", fontSize: 14, fontWeight: 600, marginBottom: 6 }}>
          Dit svar
        </label>
        <textarea
          id="answerBox"
          placeholder="Skriv dit svar her"
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          style={{
            width: "100%",
            minHeight: 160,
            backgroundColor: "#ffffff",
            color: "#000",
            border: "1px solid #cbd5e1",
            borderRadius: 6,
            padding: 10,
            resize: "vertical",
            filter: "none",
            WebkitAppearance: "none",
            appearance: "none",
          }}
        />
        <div style={{ marginTop: 10, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
          <label htmlFor="bgrefs" style={{ fontSize: 14, display: "inline-flex", alignItems: "center", gap: 6 }}>
            <input
              id="bgrefs"
              type="checkbox"
              checked={includeBackground}
              onChange={(e) => setIncludeBackground(e.target.checked)}
            />
            Inddrag baggrundslitteratur
          </label>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              onClick={evaluate}
              disabled={loadingEval || !question}
              style={{ border: "1px solid #cbd5e1", padding: "6px 10px", borderRadius: 6, opacity: loadingEval || !question ? .6 : 1 }}
            >
              {loadingEval ? "Evaluerer..." : "Evaluer svar"}
            </button>
            <button
              onClick={resetAnswer}
              style={{ border: "1px solid #cbd5e1", padding: "6px 10px", borderRadius: 6 }}
            >
              Ryd
            </button>
          </div>
        </div>
      </div>

      {/* --- FEEDBACK (én ren hvid boks) --- */}
      {result && (
        <section style={{ display: "grid", gap: 8 }}>
          <h2 style={{ fontSize: 20, fontWeight: 700 }}>Feedback</h2>

          <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
            <div style={{ fontSize: 28, fontWeight: 700 }}>{typeof result.score === "number" ? result.score : ""}</div>
            <div style={{ opacity: 0.7 }}>/ 100</div>
          </div>

          <div
            id="feedbackBox"
            style={{
              backgroundColor: "#ffffff",
              color: "#000",
              border: "1px solid #cbd5e1",
              borderRadius: 8,
              padding: 12,
              whiteSpace: "pre-wrap",
              lineHeight: 1.5,
              filter: "none",
              WebkitAppearance: "none",
              appearance: "none",
            }}
          >
            {result.feedback ?? ""}

            {!!(result.references && result.references.length) && (
              <div style={{ marginTop: 10 }}>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>Baggrundslitteratur</div>
                <ul style={{ paddingLeft: 18, margin: 0 }}>
                  {result.references!.map((r, i) => (
                    <li key={i} style={{ wordBreak: "break-word" }}>
                      {r.url ? (
                        <a href={r.url} target="_blank" rel="noreferrer" style={{ textDecoration: "underline" }}>
                          {r.title || r.url}
                        </a>
                      ) : (
                        <span>{r.title ?? "Ukendt"}</span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </section>
      )}
    </section>
  );
}

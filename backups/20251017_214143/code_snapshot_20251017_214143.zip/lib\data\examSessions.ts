﻿/* eslint-disable @typescript-eslint/no-explicit-any */
import { getSupabaseServer } from "@/lib/supabase/server";

export type ExamSession = {
  id: string;
  question: string | null;
  answer?: string | null;
  score: number | null;
  feedback: string | null;
  created_at: string;
};

export async function getLatestExamSessions(limit = 5): Promise<ExamSession[]> {
  const supabase = await await getSupabaseServer();
  const { data: { user }, error: userErr } = await supabase.auth.getUser();
  if (userErr || !user) return [];
  const { data, error } = await supabase
    .from("exam_sessions")
    .select("id, question, score, feedback, created_at")
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) { console.error("getLatestExamSessions error", error); return []; }
  return data ?? [];
}

export async function getExamSessionsPage(page = 1, pageSize = 10) {
  const supabase = await await getSupabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { items: [], count: 0 };
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  const { data, error, count } = await supabase
    .from("exam_sessions")
    .select("id, question, score, feedback, created_at", { count: "exact" })
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false })
    .range(from, to);
  if (error) { console.error("getExamSessionsPage error", error); return { items: [], count: 0 }; }
  return { items: data ?? [], count: count ?? 0 };
}

export async function getExamSessionById(id: string) {
  const supabase = await await getSupabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data, error } = await supabase
    .from("exam_sessions")
    .select("id, question, answer, score, feedback, created_at, owner_id")
    .eq("id", id)
    .single();
  if (error) { console.error("getExamSessionById error", error); return null; }
  if (!data || (data as any).owner_id !== user.id) return null;
  const { owner_id, ...rest } = data as any;
  return rest as ExamSession;
}


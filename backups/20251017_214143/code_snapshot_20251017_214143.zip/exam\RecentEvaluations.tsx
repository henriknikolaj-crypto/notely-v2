﻿/* Server Component */
import Link from "next/link";
import { getSupabaseServer } from "@/lib/supabase/server";

export default async function RecentEvaluations() {
  const supabase = await getSupabaseServer();

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from("exam_sessions")
    .select("id, created_at, question, score")
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false })
    .limit(5);

  if (error) {
    console.error("recent-evals error:", error);
    return null;
  }

  async function delAction(formData: FormData) {
    "use server";
    const id = formData.get("id") as string | null;
    if (!id) return;
    const supa = getSupabaseServer();
    const { data: { user: u } } = await supa.auth.getUser();
    if (!u) return;
    await supa.from("exam_sessions")
      .delete()
      .eq("id", id)
      .eq("owner_id", u.id);
  }

  return (
    <section className="mt-6">
      <h2 className="text-xl font-semibold">Seneste vurderinger</h2>
      <ul className="divide-y">
        {data?.map((it) => (
          <li key={it.id} className="py-2">
            <div className="text-sm opacity-70">
              {new Date(it.created_at).toLocaleString("da-DK")}
            </div>
            <div className="break-words">
              <Link href={`/exam/${it.id}`} className="underline">
                {it.question}
              </Link>
            </div>
            <div className="text-sm">Score: {it.score}/100</div>
            <form action={delAction} className="inline-block mt-1">
              <input type="hidden" name="id" value={it.id} />
              <button type="submit" className="text-sm underline">Slet</button>
            </form>
          </li>
        ))}
      </ul>
      <div className="mt-2 text-right">
        <a href="/exam/history" className="underline">Se alle</a>
      </div>
    </section>
  );
}


﻿import { headers as serverHeaders } from "next/headers";
import { revalidatePath } from "next/cache";
/* eslint-disable @typescript-eslint/no-explicit-any */
import Link from "next/link";
import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";
import type { CookieOptions } from "@supabase/ssr";

export const revalidate = 0;

export default async function HistoryPage(
  ctx: { searchParams: Promise<Record<string, string | undefined>> }
) {
  const sp = await ctx.searchParams;

  // ÉN stabil beregning af page
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);
  const pageSize = 20;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  const cookieStore = await cookies();
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => {
              cookieStore.set(name, value, options as CookieOptions);
            });
          } catch {}
        },
      },
    }
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return <div className="p-4">Du skal være logget ind.</div>;

  const { data, error, count } = await supabase
    .from("exam_sessions")
    .select("id, question, score, created_at", { count: "exact" })
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false })
    .range(from, to);

  if (error) return <div className="p-4">Fejl: {error.message}</div>;

  const total = count ?? 0;
  const lastPage = Math.max(1, Math.ceil(total / pageSize));

  async function del(id: string) {
    "use server";
    await fetch(
      `${process.env.NEXT_PUBLIC_BASE_URL ?? ""}/api/exam-sessions/${id}`,
      { method: "DELETE" }
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-6">
      <Link href="/exam" className="text-sm underline">
        &larr; Tilbage
      </Link>
      <h1 className="text-2xl font-semibold mt-2">Alle vurderinger</h1>

      <ul className="mt-4 space-y-2">
        {data?.map((it) => (
          <li
            key={it.id}
            className="rounded-xl border p-3 hover:bg-gray-50 flex items-start justify-between gap-4"
          >
            <Link href={`/exam/${it.id}`} className="block flex-1">
              <div className="text-sm text-gray-600">
                {new Date(it.created_at).toLocaleString()}
              </div>
              <div className="font-medium underline">Score: {it.score}/100</div>
              <div className="text-sm underline line-clamp-2">
                {it.question}
              </div>
            </Link>
            <form action={delAction}>
  <input type="hidden" name="id" value={it.id} />
              <input type="hidden" name="id" value={it.id} />   <button className="text-sm underline" type="submit">
                Slet
              </button>
            </form>
          </li>
        ))}
      </ul>

      <nav className="mt-6 flex items-center gap-3">
        <Link
          className={`rounded border px-3 py-1 ${
            page <= 1 ? "pointer-events-none opacity-50" : ""
          }`}
          href={`/exam/history?page=${page - 1}`}
        >
          Forrige
        </Link>
        <span>
          Side {page} / {lastPage}
        </span>
        <Link
          className={`rounded border px-3 py-1 ${
            page >= lastPage ? "pointer-events-none opacity-50" : ""
          }`}
          href={`/exam/history?page=${page + 1}`}
        >
          Næste
        </Link>
      </nav>
    </div>
  );
}


async function delAction(formData: FormData) {
  "use server";
  const id = String(formData.get("id") ?? "");
  if (!id) return;

  const h = serverHeaders();
  const host = h.get("host") ?? "localhost:3000";
  const proto = process.env.VERCEL ? "https" : "http";
  const url = new URL(`/api/exam-sessions/${id}`, `${proto}://${host}`);

  const res = await fetch(url, {
    method: "DELETE",
    headers: { cookie: h.get("cookie") ?? "" },
  });

  if (!res.ok) {
    const msg = await res.text().catch(() => "");
    throw new Error(`Slet fejlede (${res.status}): ${msg}`);
  }

  revalidatePath("/exam/history");
  revalidatePath("/exam");
}



